/********************************************************************************************************************/
/*  Cpu0_Main.c                                                                                                     */
/*                                                                                                                  */
/*  Modul "Steuergeraete/Software/Vernetzung - Embedded Systems II"                                                 */
/*  Uebung 2-02: Demonstration of a simple non-preemptive scheduler                                                 */
/*                                                                                                                  */
/*  Hochschule Mittweida, INW                                                                                       */
/*  Prof. J. Thomanek                                                                                               */
/*                                                                                                                  */
/********************************************************************************************************************/

/*********************************************************************************************************************/
/*-----------------------------------------------------Includes------------------------------------------------------*/
/*********************************************************************************************************************/

// Standard C Libratry
#include <stdbool.h>

// Infineon Low Level Drivers
#include "Ifx_Types.h"
#include "IfxCpu.h"
#include "IfxScuWdt.h"
#include "IfxPort.h"

// Project Includes
#include "Scheduler.h"

/*********************************************************************************************************************/
/*------------------------------------------------------Constants Definitions----------------------------------------*/
/*********************************************************************************************************************/

#define PORT_LED_RED     &MODULE_P10,1
#define PORT_LED_YELLOW  &MODULE_P10,5
#define PORT_LED_GREEN   &MODULE_P02,6

/*********************************************************************************************************************/
/*------------------------------------------------------Task Definitions---------------------------------------------*/
/*********************************************************************************************************************/

// ---> TODO: Define the task functions here <---

// Cyclic Task 1 - cycle time 100 ms
// ---------------------------------------------------------


// Cyclic Task 2 - cycle time 500 ms
// ---------------------------------------------------------


// Cyclic Task 3 - cycle time 1000 ms
// ---------------------------------------------------------


IFX_ALIGN(4) IfxCpu_syncEvent g_cpuSyncEvent = 0;

/*********************************************************************************************************************/
/*-------------------------------------------------Main Function-----------------------------------------------------*/
/*********************************************************************************************************************/
void core0_main(void)
{
    IfxCpu_enableInterrupts();
    IfxScuWdt_disableCpuWatchdog(IfxScuWdt_getCpuWatchdogPassword());
    IfxScuWdt_disableSafetyWatchdog(IfxScuWdt_getSafetyWatchdogPassword());
    IfxCpu_emitEvent(&g_cpuSyncEvent);
    IfxCpu_waitEvent(&g_cpuSyncEvent, 1);
    
    /*****************************************************************************************************************/
    /*-------------------------------------------------Modules Initialization----------------------------------------*/
    /*****************************************************************************************************************/

    // Initialize PORT_LED_RED as output
    IfxPort_setPinModeOutput(PORT_LED_RED, IfxPort_OutputMode_pushPull, IfxPort_OutputIdx_general);

    // Initialize PORT_LED_YELLOW as output
    IfxPort_setPinModeOutput(PORT_LED_YELLOW, IfxPort_OutputMode_pushPull, IfxPort_OutputIdx_general);

    // Initialize PORT_LED_GREEN as output
    IfxPort_setPinModeOutput(PORT_LED_GREEN, IfxPort_OutputMode_pushPull, IfxPort_OutputIdx_general);

    // Initialize the scheduler
    SchedInit();

    // ---> TODO: Add the user tasks here <----

    /*****************************************************************************************************************/
    /*-------------------------------------------------Main Loop-----------------------------------------------------*/
    /*****************************************************************************************************************/
    while(1)
    {
        // Run the scheduler
        SchedRun();
    }
}
